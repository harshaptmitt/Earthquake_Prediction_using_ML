from flask import Flask, render_template, request, redirect, url_for, session, flash
import pandas as pd
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)
app.secret_key = 'your_random_secret_key'  
model = joblib.load("earthquake_model.pkl")
scaler = joblib.load("scaler.pkl")
label_encoder = joblib.load("label_encoder.pkl")

# Load KMeans model and scaler
kmeans_eq = joblib.load("earthquake_severity_model.pkl")  # <-- your saved kmeans model
scaler_eq = joblib.load("earthquake_severity_scaler.pkl")  # <-- your saved scaler for kmeans

@app.route('/', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        if username == "admin" and password == "admin":
            return redirect(url_for('home'))
        else:
            msg = 'Incorrect username/password!'
    return render_template('login.html', msg=msg)

@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/result')
def result():
    return render_template('product.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        try:
            # Get form data
            latitude = float(request.form['latitude'])
            longitude = float(request.form['longitude'])
            depth = float(request.form['depth'])
            mag = float(request.form['mag'])
            rms = float(request.form['rms'])
            depthError = float(request.form['depthError'])

            features = [latitude, longitude, depth, mag, rms, depthError]

            # Scale features for main model
            scaled_features = scaler.transform([features])

            # Main model prediction
            prediction_encoded = model.predict(scaled_features)[0]
            prediction_label = label_encoder.inverse_transform([prediction_encoded])[0]

            suggestion = ""
            severity_text = ""

            if prediction_label == "earthquake warning":
                # If earthquake warning, predict severity using KMeans

                # Prepare only required features for severity prediction
                severity_features = np.array([[mag, depth, rms, depthError]])

                # Scale for KMeans model
                severity_features_scaled = scaler_eq.transform(severity_features)

                # Predict cluster
                cluster = kmeans_eq.predict(severity_features_scaled)[0]

                # Map cluster to severity
                cluster_to_severity = {
                    0: 'Minimum',
                    1: 'Severe',
                    2: 'Moderate'
                }

                severity_label = cluster_to_severity.get(cluster, "Unknown")

                # Add severity to suggestion
                severity_text = f"Predicted Severity: {severity_label}"
                suggestion = "⚠️ Stay alert. Prepare emergency kits and identify safe shelter locations."

            elif prediction_label == "explosion":
                suggestion = "🚨 Immediate evacuation may be required. Follow local authority guidance."
            else:
                suggestion = "✅ No immediate threat detected. Stay informed via reliable sources."

            return render_template(
                'product.html', 
                prediction_text=f"Predicted Class: {prediction_label}",
                severity_text=severity_text,
                suggestion_text=suggestion,
                latitude=latitude,
                longitude=longitude
            )
        except Exception as e:
            return render_template('product.html', prediction_text=f"Error: {str(e)}")


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
